import axios from "axios";

 export default class CountryAPI {

    async getCountriesByRegion(region) {

        const response = await axios.get(`https://restcountries.com/v3.1/region/${region}`);
        return response;
    }

}