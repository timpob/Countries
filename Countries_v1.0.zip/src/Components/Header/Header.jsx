import React from 'react';

const Header = () => {
    return (
        <div>
            <div>
                <div>Europe</div>
                <div>Asia</div>
                <div>Africa</div>
                <div>Americas</div>
                <div>Oceania</div>
            </div>
        </div>
    );
};

export default Header;