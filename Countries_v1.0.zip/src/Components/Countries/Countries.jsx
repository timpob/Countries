import React from 'react';
import {connect} from "react-redux";

const Countries = (props) => {

     console.log(props.countriesNames)

    // let arrCountries = props.countriesNames.map((el)=><div>{el.name.common}</div>)
    return (
        <div>
            {/*{arrCountries}*/}
        </div>
    );
};

const mapStateToProps = (state)=>{
    return {
        countriesNames : state.countries,
    }
}

export default connect(mapStateToProps)(Countries);