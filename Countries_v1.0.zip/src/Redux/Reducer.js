import countries from "../Components/Countries/Countries";

const SET_COUNTRIES = 'SET_COUNTRIES';


let initialState = {
    countries:[
        {name:{common:"Ukraine"}},
        {name:{common:"Poland"}},
        {name:{common:"Germany"}},
    ],

};

let Reducer = (state = initialState, action) =>{
    if(action.type === SET_COUNTRIES){
        console.log("from SetCountries branch")
    const newState = {...state,
            countries: action.countries
    }
    return newState;
    }

    return state;
};

export const setCountriesAC = (arrCountries) =>{
    return {type: SET_COUNTRIES, arrCountries:arrCountries}
}

export default Reducer;

