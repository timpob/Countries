import './App.css';
import CountryAPI from "./Services/CountryAPI";

import Header from "./Components/Header/Header";
import Countries from "./Components/Countries/Countries";
import {setCountriesAC} from "./Redux/Reducer";
import {connect} from "react-redux";
import {useEffect} from "react";

function App(props) {

    useEffect(()=>{

        const api = new CountryAPI();
        api.getCountriesByRegion("Europe")
            .then((res)=>{
                console.log("from useEf")
                props.setCountries(res.data);
            })

    }, [])



    return (
        <div className="App">
            <Header/>
            <Countries/>
        </div>
    );
}

const mapDispatchToProps = (dispatch)=>{
    return{
        setCountries :(arrCountries)=> {
            dispatch(setCountriesAC(arrCountries))
        }
    }
}

export default connect(null, mapDispatchToProps)(App);
